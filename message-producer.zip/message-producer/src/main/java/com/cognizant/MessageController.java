package com.cognizant;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;

@RestController
public class MessageController {

	@PostMapping("/sendmessage")
	public String sendMessage(@RequestBody String message) {
		
		AmazonSQS sqs=AmazonSQSClientBuilder.standard().build();
		
		String queueUrl="https://sqs.us-east-2.amazonaws.com/222512976514/intcde2930-sqs";
		
		Map<String,MessageAttributeValue> messageAttributes=new HashMap<>();
		
		messageAttributes.put("Name", new MessageAttributeValue()
				.withStringValue("Cognizant")
				.withDataType("String"));
		
		SendMessageRequest sendMessage=new SendMessageRequest()
				.withQueueUrl(queueUrl)
				.withMessageBody(message)
				.withMessageAttributes(messageAttributes)
				.withDelaySeconds(0);
		
		SendMessageResult result=sqs.sendMessage(sendMessage);
		System.out.println(result.getMessageId());
		return "Message Sent";
	}

}
