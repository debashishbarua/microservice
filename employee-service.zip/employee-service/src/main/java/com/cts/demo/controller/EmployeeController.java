package com.cts.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.demo.model.Department;
import com.cts.demo.model.Employee;
import com.cts.demo.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/employees")
@Slf4j
public class EmployeeController {

	@Autowired
	private RestTemplate restTemplete;

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/status")
	public String getStatus() {
		return " Status Ok";
	}

	@PostMapping
	public Employee save(@RequestBody Employee employee) {
		// Call Department Service
		/*
		 * Department department =
		 * restTemplete.getForObject("http://department-service/departments/" +
		 * employee.getDeptId(), Department.class);
		 */
		Department department = restTemplete.getForObject("http://localhost:9000/departments/" + employee.getDeptId(),
				Department.class);
		log.debug("Department :{}",department);
		if (department != null) {
			return employeeService.save(employee);
		} else {
			throw new RuntimeException("Department Not Exists");
		}
	}

	@GetMapping
	public List<Employee> findAll() {
		return employeeService.findAll();
	}

	@GetMapping("/{id}")
	public Employee findAll(@PathVariable int id) {
		return employeeService.findById(id);
	}

}
