package com.cts.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.demo.model.Department;
import com.cts.demo.model.Employee;







public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
