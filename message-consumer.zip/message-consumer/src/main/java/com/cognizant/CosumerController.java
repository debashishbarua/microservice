package com.cognizant;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;

@RestController
public class CosumerController {
	
	@GetMapping("/readmessage")
	public String getMessage() {
		AmazonSQS sqs=AmazonSQSClientBuilder.standard().build();
		
		String queueUrl="https://sqs.us-east-2.amazonaws.com/222512976514/intcde2930-sqs";
		
		ReceiveMessageRequest receiveMessageRequest=new ReceiveMessageRequest().withQueueUrl(queueUrl);
		
		receiveMessageRequest.setMaxNumberOfMessages(10);
		receiveMessageRequest.setWaitTimeSeconds(29);
		
		String response="";
		while(true) {
			List<Message> messages=sqs.receiveMessage(queueUrl).getMessages();
			if(!messages.isEmpty()) {
				for (Message message : messages) {
					response +=message.toString();
					sqs.deleteMessage(queueUrl,message.getReceiptHandle());
				}
			}else {
				break;
			}
		}
		return response;
	}
}
