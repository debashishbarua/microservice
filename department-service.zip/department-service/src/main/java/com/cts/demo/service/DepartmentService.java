package com.cts.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.demo.model.Department;
import com.cts.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;

	public Department save(Department department) {

		return departmentRepository.save(department);
	}

	public List<Department> findAll() {

		return departmentRepository.findAll();
	}

	public Department findById(int id) {

		return departmentRepository.findById(id).get();
	}

}
