package com.cognizant.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.exception.DepartmentNotFoundException;
import com.cognizant.model.Department;
import com.cognizant.repositories.DepartmentRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;

	@Transactional
	public List<Department> findAll() {
		log.info("Start");
		return departmentRepository.findAll();
	}

	@Transactional
	public Department findById(int id) throws DepartmentNotFoundException{
		log.info("Start");
		Optional<Department> optionalDept=departmentRepository.findById(id);
		if(optionalDept.isPresent()) {
			return optionalDept.get();
		}else {
			throw new DepartmentNotFoundException("Department Not Found With Id: " + id);
		}
	}

	public Department save(Department department) {
		return departmentRepository.save(department);
	}
}
