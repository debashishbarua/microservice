package com.cognizant.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cognizant.model.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalErrorHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(DepartmentNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleTokenValidationFailedException(DepartmentNotFoundException e) {
		log.info("START");
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setStatus(HttpStatus.NOT_FOUND);
		errorResponse.setMessage(e.getMessage());
		errorResponse.setReason(e.getLocalizedMessage());		
		errorResponse.setLocalDateTime(LocalDateTime.now());
		log.info("END");
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
}
