package com.cognizant.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Department;
import com.cognizant.services.DepartmentService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/departments")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;

	@GetMapping("/health")
	public String getStatus() {
		return "Health OK";
	}

	@GetMapping()
	public ResponseEntity<?> findAll() {
		ResponseEntity<?> responseEntity = null;
		log.info("Start");
		List<Department> departments = departmentService.findAll();
		log.debug("Departments: {}", departments);
		if (!departments.isEmpty()) {
			responseEntity = new ResponseEntity<>(departments, HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<>("Empty List", HttpStatus.OK);
		}
		return responseEntity;
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> findById(@PathVariable("id") int id) {
		log.info("Start");
		ResponseEntity<?> responseEntity = null;
		Department department = departmentService.findById(id);
		if (department != null) {
			responseEntity = new ResponseEntity<>(department, HttpStatus.OK);
		}else {
			responseEntity = new ResponseEntity<>(department, HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@PostMapping()
	public Department findById(@RequestBody Department department) {
		log.info("Start");
		return departmentService.save(department);
	}

	@PutMapping("/{id}")
	public Department findById(@RequestBody Department department, @PathVariable int id) {
		log.info("Start");
		Department dept = departmentService.findById(id);
		if (dept != null)
			return departmentService.save(department);
		else
			throw new RuntimeException(" Dept not found");
	}

}
