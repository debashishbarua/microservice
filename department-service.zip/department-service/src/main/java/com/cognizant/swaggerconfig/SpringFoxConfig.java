package com.cognizant.swaggerconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Slf4j
public class SpringFoxConfig {
	@Bean
	public Docket api() {

		Docket docket = new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.cognizant"))
				.paths(PathSelectors.any()).build().apiInfo(apiDetails());
		log.debug("Docket{}:", docket);
		return docket;
	}
	private ApiInfo apiDetails() {
		ApiInfo apiInfo = new ApiInfoBuilder().title("Department Service")
				.description("Department Service Documentation")
				.termsOfServiceUrl("Help").license("Department 1.0")
				.contact(new Contact("Department Management System", "abc.com",
						"abc.com"))
				.version("1.0").build();
		log.debug("API Info{}:", apiInfo);
		return apiInfo;
	}
}
