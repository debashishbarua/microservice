insert into department(id, name,location) values(1,'CS','Delhi');
insert into department(id, name,location) values(2,'IT','Kolkata');
insert into department(id, name,location) values(3,'EC','Mumbai');
insert into department(id, name,location) values(4,'ME','Chennai');