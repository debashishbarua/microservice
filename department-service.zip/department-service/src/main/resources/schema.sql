CREATE TABLE IF NOT EXISTS department(
id INTEGER AUTO_INCREMENT primary key,
name  VARCHAR(100),
location VARCHAR(100)
);